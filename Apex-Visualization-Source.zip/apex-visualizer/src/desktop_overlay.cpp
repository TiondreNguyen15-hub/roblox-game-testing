#include "apex/desktop_overlay.hpp"
#include "apex/log.hpp"
#include <windows.h>
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cmath>
#include <stdexcept>
namespace apex {
struct DesktopOverlay::Impl {
 struct Monitor {RECT bounds;bool primary;std::string label;};
 HWND window=nullptr;bool registered=false,excluded=false;std::vector<Monitor> displays;std::vector<std::string> labels;std::string message="Desktop overlay off";std::vector<EnemyBox> boxes;OverlayViewport viewport;TrackingOverlay tracking;float desktopLeft=0,desktopTop=0;std::string badge;std::uint64_t completed=0;std::shared_ptr<const CapturedFrame> frame;int monitor=-1;bool fit=true,showBoxes=true;unsigned sourceWidth=0,sourceHeight=0;using Clock=std::chrono::steady_clock;Clock::time_point received{},enumerated{};
 static BOOL CALLBACK collect(HMONITOR h,HDC,LPRECT,LPARAM data){auto& self=*reinterpret_cast<Impl*>(data);MONITORINFO i{};i.cbSize=sizeof(i);if(GetMonitorInfoW(h,&i))self.displays.push_back({i.rcMonitor,(i.dwFlags&MONITORINFOF_PRIMARY)!=0,{}});return TRUE;}
 void enumerate(){displays.clear();labels.clear();EnumDisplayMonitors(nullptr,nullptr,collect,reinterpret_cast<LPARAM>(this));std::stable_sort(displays.begin(),displays.end(),[](const auto& a,const auto& b){return a.primary&&!b.primary;});for(size_t n=0;n<displays.size();++n){auto& d=displays[n];d.label=(d.primary?"Primary monitor":"Monitor "+std::to_string(n+1))+std::string(" (")+std::to_string(d.bounds.right-d.bounds.left)+"x"+std::to_string(d.bounds.bottom-d.bounds.top)+")";labels.push_back(d.label);}enumerated=Clock::now();}
 static LRESULT CALLBACK proc(HWND h,UINT msg,WPARAM w,LPARAM l){auto* self=reinterpret_cast<Impl*>(GetWindowLongPtrW(h,GWLP_USERDATA));if(msg==WM_NCCREATE){self=static_cast<Impl*>(reinterpret_cast<CREATESTRUCTW*>(l)->lpCreateParams);SetWindowLongPtrW(h,GWLP_USERDATA,reinterpret_cast<LONG_PTR>(self));}if(msg==WM_NCHITTEST)return HTTRANSPARENT;if(msg==WM_MOUSEACTIVATE)return MA_NOACTIVATE;if(msg==WM_ERASEBKGND)return 1;if(msg==WM_PRINTCLIENT&&self){auto dc=reinterpret_cast<HDC>(w);RECT r;GetClientRect(h,&r);FillRect(dc,&r,static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));self->paint(dc);return 0;}if(msg==WM_PAINT&&self){PAINTSTRUCT ps{};HDC dc=BeginPaint(h,&ps);RECT r;GetClientRect(h,&r);FillRect(dc,&r,static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));self->paint(dc);EndPaint(h,&ps);return 0;}return DefWindowProcW(h,msg,w,l);}
 void paint(HDC dc){auto pen=CreatePen(PS_SOLID,2,RGB(210,110,255));auto oldPen=SelectObject(dc,pen);auto oldBrush=SelectObject(dc,GetStockObject(HOLLOW_BRUSH));auto oldFont=SelectObject(dc,GetStockObject(DEFAULT_GUI_FONT));SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(240,210,255));TextOutA(dc,12,12,badge.c_str(),static_cast<int>(badge.size()));if(tracking.visible){int cx=int(tracking.centerX-desktopLeft),cy=int(tracking.centerY-desktopTop),radius=int(tracking.radius);Ellipse(dc,cx-radius,cy-radius,cx+radius,cy+radius);if(tracking.marker){int x=int(tracking.targetX-desktopLeft),y=int(tracking.targetY-desktopTop);MoveToEx(dc,x-5,y,nullptr);LineTo(dc,x+6,y);MoveToEx(dc,x,y-5,nullptr);LineTo(dc,x,y+6);}}for(const auto& b:boxes){int x=int(viewport.x+b.x1*viewport.width),y=int(viewport.y+b.y1*viewport.height),right=int(viewport.x+b.x2*viewport.width),bottom=int(viewport.y+b.y2*viewport.height);Rectangle(dc,x,y,right,bottom);char label[64];int n=snprintf(label,sizeof(label),"Enemy? %.2f",b.score);TextOutA(dc,x,std::max(30,y-16),label,n);}SelectObject(dc,oldFont);SelectObject(dc,oldBrush);SelectObject(dc,oldPen);DeleteObject(pen);}
 void create(){if(window)return;WNDCLASSEXW wc{};wc.cbSize=sizeof(wc);wc.hInstance=GetModuleHandleW(nullptr);wc.lpfnWndProc=proc;wc.lpszClassName=L"ApexVisualizationDesktopOverlay";if(!RegisterClassExW(&wc))throw std::runtime_error("Desktop overlay class registration failed: "+std::to_string(GetLastError()));registered=true;window=CreateWindowExW(WS_EX_TOPMOST|WS_EX_LAYERED|WS_EX_TRANSPARENT|WS_EX_NOACTIVATE|WS_EX_TOOLWINDOW,wc.lpszClassName,L"Game ESP Desktop Overlay",WS_POPUP,0,0,1,1,nullptr,nullptr,wc.hInstance,this);if(!window)throw std::runtime_error("Desktop overlay creation failed: "+std::to_string(GetLastError()));if(!SetLayeredWindowAttributes(window,RGB(0,0,0),255,LWA_COLORKEY))throw std::runtime_error("Desktop overlay transparency failed");excluded=SetWindowDisplayAffinity(window,0x00000011)!=FALSE;if(!excluded)Log::write("WARN","Overlay capture exclusion unavailable; prefer OBS Window Capture of the game");}
 ~Impl(){if(window)DestroyWindow(window);if(registered)UnregisterClassW(L"ApexVisualizationDesktopOverlay",GetModuleHandleW(nullptr));}
};
DesktopOverlay::DesktopOverlay():impl_(std::make_unique<Impl>()){impl_->enumerate();}
DesktopOverlay::~DesktopOverlay()=default;
const std::vector<std::string>& DesktopOverlay::monitors()const{return impl_->labels;}
const std::string& DesktopOverlay::status()const{return impl_->message;}
bool DesktopOverlay::visible()const{return impl_->window&&IsWindowVisible(impl_->window);}
void DesktopOverlay::update(const DesktopOverlayOptions& o,const EnemySnapshot& result,bool live,unsigned w,unsigned h,const TrackingOverlay& requestedTracking){
 TrackingOverlay hidden;bool valid=std::isfinite(requestedTracking.centerX)&&std::isfinite(requestedTracking.centerY)&&std::isfinite(requestedTracking.targetX)&&std::isfinite(requestedTracking.targetY)&&std::isfinite(requestedTracking.radius)&&requestedTracking.radius>=20&&requestedTracking.radius<=800;TrackingOverlay tracking=valid?requestedTracking:hidden;auto& s=*impl_;auto now=Impl::Clock::now();
 if(!o.enabled){if(s.window)ShowWindow(s.window,SW_HIDE);s.boxes.clear();s.frame.reset();s.completed=0;s.message="Screen overlay off";return;}
 try{
  if(now-s.enumerated>std::chrono::seconds(2)){s.enumerate();s.monitor=-1;}if(s.displays.empty())throw std::runtime_error("No desktop monitor available");s.create();int monitor=std::clamp(o.monitor,0,int(s.displays.size())-1);auto r=s.displays[monitor].bounds;
  if(tracking.useMonitorCenter){tracking.centerX=float(r.left+r.right)*.5f;tracking.centerY=float(r.top+r.bottom)*.5f;}
  if(!live)tracking.marker=false;
  bool dirty=o.showBoxes!=s.showBoxes||tracking.visible!=s.tracking.visible||tracking.marker!=s.tracking.marker||tracking.centerX!=s.tracking.centerX||tracking.centerY!=s.tracking.centerY||tracking.radius!=s.tracking.radius||tracking.targetX!=s.tracking.targetX||tracking.targetY!=s.tracking.targetY||tracking.label!=s.tracking.label;s.tracking=tracking;s.showBoxes=o.showBoxes;s.desktopLeft=float(r.left);s.desktopTop=float(r.top);
  if(monitor!=s.monitor||o.fitAspect!=s.fit||w!=s.sourceWidth||h!=s.sourceHeight){s.monitor=monitor;s.fit=o.fitAspect;s.sourceWidth=w;s.sourceHeight=h;s.viewport=overlayViewport(float(r.right-r.left),float(r.bottom-r.top),w,h,o.fitAspect);if(!SetWindowPos(s.window,HWND_TOPMOST,r.left,r.top,r.right-r.left,r.bottom-r.top,SWP_NOACTIVATE))throw std::runtime_error("Screen overlay positioning failed");dirty=true;}
  if(result.completed!=s.completed||result.analyzedFrame!=s.frame){s.completed=result.completed;s.frame=result.analyzedFrame;dirty=true;}
  bool fresh=live&&enemyResultFresh(result,o.maxResultAgeMs,now);
  std::string state=!live?"connect live OBS capture":fresh?(result.latest.cudaVerified?"CUDA result":"CPU / GPU not verified"):"waiting for fresh detections";
  auto badge=std::string("APEX VISION | SCREEN OVERLAY ON | ")+state+" | F8 hide";
  if(tracking.visible)badge+=" | FOV circle";if(!s.excluded)badge+=" | capture exclusion unavailable";
  if(badge!=s.badge){s.badge=badge;dirty=true;}
  if(fresh&&o.showBoxes){if(dirty)s.boxes=result.latest.boxes;}else if(!s.boxes.empty()){s.boxes.clear();dirty=true;}
  s.message="Desktop overlay active on "+s.displays[monitor].label+"; "+state;
  if(tracking.visible&&(tracking.centerX<r.left||tracking.centerX>=r.right||tracking.centerY<r.top||tracking.centerY>=r.bottom))s.message+="; FOV is outside this display: choose the game monitor";
  if(!s.excluded)s.message+="; use OBS Window Capture to avoid feedback";
  if(!IsWindowVisible(s.window)){ShowWindow(s.window,SW_SHOWNOACTIVATE);dirty=true;}if(dirty){InvalidateRect(s.window,nullptr,FALSE);UpdateWindow(s.window);}
 }catch(const std::exception& e){if(s.window)ShowWindow(s.window,SW_HIDE);auto error=std::string("Overlay unavailable: ")+e.what();if(s.message!=error)Log::write("WARN",error);s.message=error;}
}
}
